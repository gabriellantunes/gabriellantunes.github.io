package Program;

import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException { //throws InterruptedException para utilizar o cronometro da exibição das mensagens

        Locale.setDefault(Locale.US);
        Scanner leitor = new Scanner(System.in);

        //System.out.println();
        //System.out.println("Ola !!");
        //Thread.sleep(5000);
        //System.out.println("Eu sou uma inteligencia artificial criado por alunos da Univille e meu intuito e tentar adivinhar o time que voce esteja pensando !!");
        //Thread.sleep(6000);
        //System.out.println("Por favor seja paciente, embora tenha sido desenvolvido para ter o maximo de precisao, excecoes podem ocorrer.");
        //Thread.sleep(7000);
        //System.out.println();
        //System.out.println("Duas pequnas observacoes antes de iniciarmos essa jornada: ");
        //System.out.println("1. Se o seu time nao faz parte da serie A ou Serie B do campeonato brasileiro de 2023 nunca conseguirei adivinhar.");
        //System.out.println("2. Voce precisa digitar exatamente igual as opcoes de respostas que irei sujerir dentro de parenteses, ok ? ");
        //System.out.println("3. Caso nao saiba das respostas pesquise no google, pois dependendo das suas respostas a resposta final pode mudar.");
        //System.out.println();

        //Thread.sleep(8500);
        //System.out.println("Sendo assim, vamos la !!");
        //Thread.sleep(8700);

        //System.out.println();
        //System.out.println("Estou tentando adivinhar o time brasileiro em que voce tem em mente. ");
        //System.out.println("Mas para isso preciso que voce me conceda algumas informacoes !");
        //System.out.println();

        System.out.println();
        System.out.println("Seu time joga na serie A no campeonato brasileiro de 2023 (sim/nao) ?");
        System.out.print("R: ");
        String serieA = leitor.nextLine();

        if (serieA.equals("sim")) { //Apenas times da serie A
            //codigo

            System.out.println();
            System.out.println("Hmmm, tenho alguns palpites em mente !");
            System.out.println();
            System.out.println("Seu time que joga na serie A, e de qual regiao do Brasil (norte/nordeste/centro-oeste/sudeste/sul) ?");
            System.out.print("R: ");
            String regiao = leitor.nextLine();

            switch (regiao) {
                case "norte":
                    //times serie A do norte:
                    System.out.println();
                    System.out.println("Desculpe.");
                    System.out.println("A regiao do norte atualmente nao possui times jogando na Serie A.");

                    break;

                case "nordeste":  //SE CAIR AQUI É PQ O TIME É NORDESTINO
                    //Times da serie A do nordeste(3):
                    //Bahia
                    //Fortaleza
                    System.out.println();
                    System.out.println("Seu time que joga na serie A e se localiza na regiao do nordeste possui como brasao/escudo uma bandeira (sim/nao) ?");
                    System.out.print("R: ");
                    String primeiraDecisaoNordeste = leitor.nextLine();

                    //--------------------------------------------BAHIA-----------------------------------------------------
                    if (primeiraDecisaoNordeste.equals("sim")) { //SE CAIR AQUI É PQ O TIME É NORDESTINO,E TEM UM BRASAO DE UMA BANDEIRA
                        //código

                        System.out.println();
                        System.out.println("Seu time que joga na serie A, se localiza na regiao do nordeste possui como brasao/escudo uma bandeira, este time e do Salvador (sim/nao) ?");
                        System.out.print("R: ");
                        String segundaDecisaoNordeste = leitor.nextLine();

                        if (segundaDecisaoNordeste.equals("sim")) { //SE CAIR AQUI É PQ O TIME É NORDESTINO, POSSUI UMA BRASAO DE BANDEIRA E É DO SALVADOR
                            //código

                            System.out.println();
                            System.out.println("Seu time que joga na serie A, se localiza na regiao do nordeste possui como brasao/escudo uma bandeira, e do Salvador, possui um Super Homem como mascote (sim/nao) ?");
                            System.out.print("R: ");
                            String terceiraDescisaoNordeste = leitor.nextLine();

                            if (terceiraDescisaoNordeste.equals("sim")) { //SE CAIR AQUI É PQ O TIME É NORDESTINO, POSSUI UM BRASAO DE BANDEIRA, É DO SALVADOR E POSSUI UM SUPER HOMEM COMO MASCOTE
                                //codigo

                                System.out.println();
                                System.out.println("Time: Bahia");
                                System.out.println("Regiao: Nordeste");
                                System.out.println("Ano Fundacao: 1931");
                                System.out.println("Mascote: Super Homem");
                                System.out.println("Estadio: Itaipava Arena Fonte Nova");
                                System.out.println("Cidade: Salvador");

                            } else if (terceiraDescisaoNordeste.equals("nao")) { //SE CAIR AQUI É PQ O TIME É NORDESTINO, POSSUI UM BRASAO DE BANDEIRA, É DO SALVADOR E  NAO POSSUI UM SUPER HOMEM COMO MASCOTE, LOGO N EXISTE TIME COM ESSAS INFORMAÇÕES

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                System.out.println("Atualmente nao possui nenhum clube que joga na serie A, reside no Nordeste, possui uma bandeira como brasao/escudo e que nao possua um Super Homem como mascote");

                                System.out.println();
                                System.out.println("Mesmo suas respostas possuindo divergencias acredito que esteja pensando no: ");
                                System.out.println();

                                System.out.println("Time: Bahia");
                                System.out.println("Regiao: Nordeste");
                                System.out.println("Ano Fundacao: 1931");
                                System.out.println("Mascote: Super Homem");
                                System.out.println("Estadio: Itaipava Arena Fonte Nova");
                                System.out.println("Cidade: Salvador");

                            } else {
                                //codigo falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if ((segundaDecisaoNordeste.equals("nao"))) {
                            //codigo caso nao

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                            System.out.println("Atualmente nao existe um clube que joga na serie A, possui uma bandeira como brasao e que nao resida em Salvador.");

                            System.out.println();
                            System.out.println("Mesmo com as respostas possuindo divergencias, acredito que voce esteja pensando no: ");
                            System.out.println();

                            System.out.println("Time: Bahia");
                            System.out.println("Regiao: Nordeste");
                            System.out.println("Ano Fundacao: 1931");
                            System.out.println("Mascote: Super Homem");
                            System.out.println("Estadio: Itaipava Arena Fonte Nova");
                            System.out.println("Cidade: Salvador");


                        } else { //SE CAIR AQUI É PQ O TIME É NORDESTINO, POSSUI UMA BRASAO DE BANDEIRA E NÃO É DO SALVADOR
                            //código

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }//----------------------------------------FIM BAHIA------------------------------------------------

                        //-----------------------------------------FORTALEZA------------------------------------------------
                    } else if (primeiraDecisaoNordeste.equals("nao")) { //SE CAIR AQUI É PQ O TIME JOGA NA SERIE A, É NORDESTINO,E NÃO TEM O BRASAO DE UMA BANDEIRA
                        //código caso nao

                        System.out.println();
                        System.out.println("Seu time que joga na serie A, se localiza na regiao do nordeste e nao possui brasao de uma bandeira possui um estadio chamado 'Castelao' (sim/nao) ? ");
                        System.out.print("R: ");
                        String quartaDecisaoNordeste = leitor.nextLine();

                        if (quartaDecisaoNordeste.equals("sim")) { //SE CAIR AQUI É PQ O TIME JOGA NA SERIE A, É NORDESTINO,NÃO TEM O BRASAO DE UMA BANDEIRA, TEM UM ESTADIO CHAMADO CASTELAO
                            //codigo

                            System.out.println();
                            System.out.println("Seu time que joga na serie A, se localiza na regiao do nordeste, nao possui brasao de uma bandeira, possui um estadio chamado 'Castelao', seu mascote e um 'Leao' apelidado de Juba (sim/nao) ?");
                            System.out.print("R: ");
                            String quintaDecisaoNordeste = leitor.nextLine();

                            if (quintaDecisaoNordeste.equals("sim")) {
                                //codigo

                                System.out.println();
                                System.out.println("Time: Fortaleza");
                                System.out.println("Regiao: Nordeste");
                                System.out.println("Ano Fundacao: 1918");
                                System.out.println("Estadio: Castelao(Estadio Governador Placido Castelo)");
                                System.out.println("Cidade: Salvador");

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe um time que jogue pela Serie A, reside no nordeste, nao possui um brasao de uma bandeira, possua um estadio chamado 'Castelao' e nao possua um 'Leao' de mascote.");

                            }

                        } else { //SE CAIR AQUI É PQ O TIME JOGA NA SERIE A, É NORDESTINO,NÃO TEM O BRASAO DE UMA BANDEIRA, NAO TEM UM ESTADIO CHAMADO CASTELAO
                            //código falso

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                            System.out.println("Atualmente nao existe um clube que jogue na serie A, reside no nordeste, nao possua um brasao de uma bandeira e que nao possui um estadio chamado 'Castelao'.");

                        }

                    } else {
                        //codigo falso

                        System.out.println();
                        System.out.println("Desculpe, ");
                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                        System.out.println("Obrigado e volte sempre !!");

                    }
                    //-------------------------------------FIM FORTALEZA----------------------------------------------------

                    break;

                case "centro-oeste":  //SE CAIR AQUI É PQ O TIME É DO CENTRO-OESTE
                    //Times serie A do centro-oeste(2):
                    //Cuiabá
                    //Goiás
                    System.out.println();
                    System.out.println("O time que joga na serie A, localizado na regiao Centro-Oeste, possui o mascote do time um peixe dourado (sim/nao) ?");
                    System.out.print("R: ");
                    String primeiraDecisaoCentroOeste = leitor.nextLine();

                    if (primeiraDecisaoCentroOeste.equals("sim")) { //-------------------CUIABA-----------------------------
                        //codigo

                        System.out.println();
                        System.out.println("O time que joga na serie A, localizado na regiao Centro-Oeste, que possui o mascote um peixe dourado, possui as cores do time verde e amarelo (sim/nao) ?");
                        System.out.print("R: ");
                        String segundaDecisaoCentroOeste = leitor.nextLine();

                        if (segundaDecisaoCentroOeste.equals("sim")) {
                            //codigo

                            System.out.println();
                            System.out.println("O time que joga na serie A, localizado na regiao Centro-Oeste, que possui o mascote um peixe dourado, que possui as cores do time verde e amarelo, possui mundial ?");
                            System.out.print("R: ");
                            String terceiraDecisaoCentroOeste = leitor.nextLine();

                            if (terceiraDecisaoCentroOeste.equals("sim")) {
                                //codigo

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Atualmente nao existe um time que joga na serie A, localizado na regiao Centro-Oeste, que possui o mascote um peixe dourado, que possui as cores do time verde e amarelo, e que possua mundial");
                                System.out.println();
                                System.out.println("Mesmo que suas respostas estejam com divergencias acredito que esteja pensando no:");
                                System.out.println();
                                System.out.println("Time: Cuiaba");
                                System.out.println("Ano Fundacao: 2001");
                                System.out.println("Mascote: Peixe Dourado");
                                System.out.println("Estadio: Arena Pantanal");
                                System.out.println("Cidade: Cuiaba-MG");

                            } else if (terceiraDecisaoCentroOeste.equals("nao")) {
                                //código caso nao

                                System.out.println();
                                System.out.println("Time: Cuiaba");
                                System.out.println("Ano Fundacao: 2001");
                                System.out.println("Mascote: Peixe Dourado");
                                System.out.println("Estadio: Arena Pantanal");
                                System.out.println("Cidade: Cuiaba-MG");

                            } else {
                                //codigo falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if (segundaDecisaoCentroOeste.equals("nao")) {
                            //código caso nao

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                            System.out.println("Atualmente nao existe um time que joga na serie A, localizado na regiao Centro-Oeste, que possui o mascote um peixe dourado, e que nao possua as cores do time verde e amarelo ");

                        } else {
                            //codigo falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }
                        //----------------------------------------FIM CUIABA------------------------------------------------
                    } else if (primeiraDecisaoCentroOeste.equals("nao")) { //-----------------GOIAIS------------------------
                        //código caso nao

                        System.out.println();
                        System.out.println("O time que joga na serie A, localizado na regiao Centro-Oeste, possui o mascote do time um periquito verde (sim/nao) ?");
                        System.out.print("R: ");
                        String quartaDecisaoCentroOeste = leitor.nextLine();

                        if (quartaDecisaoCentroOeste.equals("sim")) {
                            //codigo

                            System.out.println();
                            System.out.println("O time que joga na serie A, localizado na regiao Centro-Oeste, o mascote do time e um periquito verde, possui um estadio chamado 'Serrinha' ?");
                            System.out.print("R: ");
                            String quintaDecisaoCentroOeste = leitor.nextLine();

                            if (quintaDecisaoCentroOeste.equals("sim")) {
                                //código

                                System.out.println();
                                System.out.println("Time: Goiais");
                                System.out.println("Regiao: Centro-Oeste");
                                System.out.println("Ano Fundacao: 1943");
                                System.out.println("Mascote: Periquito");
                                System.out.println("Estadio: Serrinha");

                            } else if (quintaDecisaoCentroOeste.equals("nao")) {
                                //código caso nao

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe time que jogue pela serie A, localizado na regiao Centro-Oeste, cujo o mascote do time seja um periquito verde e que nao possua um estadio chamado 'Serrinha' ");

                            } else {
                                //codigo falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if (quartaDecisaoCentroOeste.equals("nao")) {
                            //código caso nao

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                            System.out.println("Atualmente nao existe um time que jogue pela serie A, localizado na regiao Centro-Oeste, nao possua como mascote um peixe dourado e nem um periquito verde");

                        } else {
                            //codigo falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else {//---------------------------------------FIM GOIAIS---------------------------------------------
                        //codigo falso

                        System.out.println();
                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                        System.out.println("Atualmente nao existe um clube que jogue na serie A, reside no nordeste, nao possua um brasao de uma bandeira e que nao possui um estadio chamado 'Castelao'.");

                    }

                    break;

                case "sudeste":
                    //Times serie A do sudeste(12):
                    //America Mineiro ----------- FEITO
                    //Atletico Mineiro----------- FEITO
                    //Bragantino
                    //Corianthians--------------FEITO
                    //Cruzeiro ------------------ FEITO
                    //Flamengo
                    //Fluminense
                    //Palmeiras
                    //Santos -----------------FEITO
                    //Sao Paulo
                    //Botafogo ---------------------FEITO
                    //Vasco da Gama-----------------FEITO
                    System.out.println();
                    System.out.println("Certo... ");
                    System.out.println("Ja preparei alguns palpites !!");
                    System.out.println();

                    System.out.println("Seu time que joga na serie A, faz parte da regiao Sudeste possui a logo do time as cores azul e branca em seu brasao/escudo (sim/nao) ?");
                    System.out.print("R: ");
                    String primeiraDecisaoSudeste = leitor.nextLine();

                    if (primeiraDecisaoSudeste.equals("sim")) { //--------------------Cruzeiro--------------------------
                        //código
                        System.out.println();
                        System.out.println("Certo...");
                        System.out.println("Seu time que joga na serie A, faz parte da regiao Sudeste, possui as cores azul e branca, possui um porco como mascote (sim/nao) ? ");
                        System.out.print("R: ");
                        String segundaDecisaoSudeste = leitor.nextLine();

                        if (segundaDecisaoSudeste.equals("nao")) {
                            //código
                            System.out.println();
                            System.out.println("Seu time que joga na serie A, faz parte da regiao Sudeste, possui as cores azul e branca, nao tem um porco como mascote possui um estadio chamado Mineirao (sim/nao) ? ");
                            System.out.print("R: ");
                            String terceiraDecisaoSudeste = leitor.nextLine();

                            if (terceiraDecisaoSudeste.equals("sim")) {//------------Caminho Cruzeiro NO INICIO(Perguntar mais)---------
                                //código caso sim

                                System.out.println();
                                System.out.println("Recentemente o ex-jogador de futebol Ronaldo fenomeno comprou 90% da SAF deste time (sim/nao) ? ");
                                System.out.print("R: ");
                                String quartaDecisaoSudeste = leitor.nextLine();

                                if (quartaDecisaoSudeste.equals("sim")) {
                                    //código

                                    System.out.println();
                                    System.out.println("Certo... tenho um palpite, mas antes... ");
                                    System.out.println("Seu time possui titulo de Libertadores (sim/nao) ? ");
                                    System.out.print("R: ");
                                    String quintaDecisaoSudeste = leitor.nextLine();

                                    if (quintaDecisaoSudeste.equals("sim")) {
                                        //código

                                        System.out.println();
                                        System.out.println("Sendo assim... aqui esta o meu palpite: ");

                                        System.out.println("Time: Cruzeiro");
                                        System.out.println("Regiao: Sudeste");
                                        System.out.println("Ano Fundacao: 1921");
                                        System.out.println("Mascote: Raposa");
                                        System.out.println("Estadio: Mineirao");
                                        System.out.println("Cidade: Belo Horizonte");

                                    } else if (quintaDecisaoSudeste.equals("nao")) {
                                        //código caso nao

                                        System.out.println();
                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                        System.out.println("Atualmente nao existe um time que joga na serie A, faz parte da regiao Sudeste, possui as cores azul e branca em seu brasao/escudo, nao possua um porco como mascote, tenha um estadio chamado Mineirao, tenha sido comprado 90% da SAF do time pelo Ronaldo e que nao possua uma Libertadores. ");

                                        System.out.println();
                                        System.out.println("Mesmo sua resposta possuindo divergencias, acredito que voce esteja pensando neste time: ");
                                        System.out.println();

                                        System.out.println("Time: Cruzeiro");
                                        System.out.println("Regiao: Sudeste");
                                        System.out.println("Ano Fundacao: 1921");
                                        System.out.println("Mascote: Raposa");
                                        System.out.println("Estadio: Mineirao");
                                        System.out.println("Cidade: Belo Horizonte");

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }


                                } else if (quartaDecisaoSudeste.equals("nao")) {
                                    //código caso nao

                                    System.out.println();
                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                    System.out.println("Atualmente nao existe um time que joga na serie A, faz parte da regiao Sudeste, possui as cores azul e branca em seu brasao/escudo, nao possua um porco como mascote, tenha um estadio chamado Mineirao e nao tenha sido comprado pelo Ronaldo. ");

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else if (terceiraDecisaoSudeste.equals("nao")) {
                                //código caso nao

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe um time que joga na serie A, faz parte da regiao Sudeste, possui as cores azul e branca em seu brasao/escudo, nao possua um porco como mascote e nao tenha um estadio chamado Mineirao ");

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if (segundaDecisaoSudeste.equals("sim")) {
                            //código caso nao

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                            System.out.println("Atualmente nao existe um time que joga na serie A, faz parte da regiao Sudeste, possui as cores azul e branca em seu brasao/escudo e possui um  porco como mascote. ");

                        } else {
                            //código falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else if (primeiraDecisaoSudeste.equals("nao")) { //----------------OUTRO TIME---------------------
                        //código caso nao
                        System.out.println();
                        System.out.println("Seu time possui as cores verde e preta em sua camiseta (sim/nao) ? ");//--------- America Mineiro
                        System.out.print("R: ");
                        String sextaDecisaoSudeste = leitor.nextLine();

                        if (sextaDecisaoSudeste.equals("sim")) { // ---------------- america mineiro--------------------
                            //código

                            System.out.println();
                            System.out.println("Certo...");
                            System.out.println("Seu time possui o Vovo Coxa como mascote (sim/nao) ? ");
                            System.out.print("R: ");
                            String setimaDecisaoSudeste = leitor.nextLine();

                            if (setimaDecisaoSudeste.equals("sim")) {
                                //código

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao Sudeste, possui uma camiseta verde e preta e possua o mascote chamado Vovo Coxa.");

                            } else if (setimaDecisaoSudeste.equals("nao")) { //----------America Mineiro----------------
                                //codigo valido caso oposto do primeiro

                                System.out.println();
                                System.out.println("Entendi...");
                                System.out.println("Seu time possui uma Libertadores ou Mundial (sim/nao) ? ");
                                System.out.print("R: ");
                                String oitavaDecisaoSudeste = leitor.nextLine();

                                if (oitavaDecisaoSudeste.equals("sim")) {
                                    //código

                                    System.out.println();
                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                    System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao Sudeste, possui uma camiseta verde e preta, nao possua o mascote chamado Vovo Coxa e tem uma Libertadores ou Mundial. ");

                                } else if (oitavaDecisaoSudeste.equals("nao")) {//--------America Mineiro
                                    //codigo valido caso oposto do primeiro

                                    System.out.println();
                                    System.out.println("Seu time possui um mascote como Coelho (sim/nao) ?");
                                    System.out.print("R: ");
                                    String nonaDecisaoSudeste = leitor.nextLine();

                                    if (nonaDecisaoSudeste.equals("sim")) { //------------America Mineiro---------------
                                        //código

                                        System.out.println();
                                        System.out.println("Tenho um palpite em mente. ");
                                        System.out.println("Seu time possui um estadio chamado Arena Independencia (sim/nao) ?");
                                        System.out.print("R: ");
                                        String decimaDecisaoSudeste = leitor.nextLine();

                                        if (decimaDecisaoSudeste.equals("sim")) {//-------America Mineiro---------------
                                            //código

                                            System.out.println();
                                            System.out.println("Acredito que seu time seja o : ");
                                            System.out.println();
                                            System.out.println("Time : America Mineiro");
                                            System.out.println("Regiao: Sudeste");
                                            System.out.println("Fundacao: 1912");
                                            System.out.println("Mascote: Coelho");
                                            System.out.println("Estadio: Arena Independencia");
                                            System.out.println("Cidade: Belo Horizonte-MG");


                                        } else if (decimaDecisaoSudeste.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                            System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao Sudeste, possui uma camiseta verde e preta, nao possua o mascote chamado Vovo Coxa, nao tem uma Libertadores ou Mundial, tenha o mascote de um Coelho e nao tem um estadio chamado Independencia. ");

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }


                                    } else if (nonaDecisaoSudeste.equals("nao")) {
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                        System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao Sudeste, possui uma camiseta verde e preta, nao possua o mascote chamado Vovo Coxa, nao tem uma Libertadores ou Mundial e nao tenha o mascote de um Coelho. ");

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }


                        } else if (sextaDecisaoSudeste.equals("nao")) {//------------Athletico Mineiro------------------

                            System.out.println();
                            System.out.println("Seu time possui uma camiseta com apenas as cores preta e branca(brasao/escudo nao e considerado) (sim/nao) ?"); //---------Athletico Mineiro, Botafogo, Corinthians, Santos, Vasco------------
                            System.out.print("R: ");
                            String decimaDecisaoSudeste = leitor.nextLine();

                            if (decimaDecisaoSudeste.equals("sim")) {
                                //código

                                System.out.println();
                                System.out.println("Seu time e de Minas Gerais (sim/nao) ?"); //-------Athletico Mineiro
                                System.out.print("R: ");
                                String decimaPrimeiraDecisaoSudeste = leitor.nextLine();

                                if (decimaPrimeiraDecisaoSudeste.equals("sim")) {
                                    //código
                                    System.out.println();
                                    System.out.println("Seu time possuiu recentemente um jogador famoso apelidado de 'Hulk' em seu elenco (sim/nao) ? ");
                                    System.out.print("R: ");
                                    String decimaSegundaDecisaoSudeste = leitor.nextLine();

                                    if (decimaSegundaDecisaoSudeste.equals("sim")) { //-------Athletico Mineiro
                                        //código

                                        System.out.println();
                                        System.out.println("Este time possui um mascote apelidado de 'Galo' (sim/nao) ? ");
                                        System.out.print("R: ");
                                        String decimaTerceiraDecisaoSudeste = leitor.nextLine();

                                        if (decimaTerceiraDecisaoSudeste.equals("sim")) {
                                            //código

                                            System.out.println();
                                            System.out.println("Acredito que o time seja o : ");
                                            System.out.println();
                                            System.out.println("Time: Athletico Mineiro");
                                            System.out.println("Regiao: Sudeste");
                                            System.out.println("Fundacao: 1908");
                                            System.out.println("Mascote: Galo");
                                            System.out.println("Estadio: Mineirao");
                                            System.out.println("Cidade: Belo Horizonte-MG");

                                        } else if (decimaTerceiraDecisaoSudeste.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                            System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao Sudeste, possui uma camiseta branca e preta, se localiza em Minas Gerais, possui o jogador 'Hulk' em seu elenco e nao possua o 'Galo' como mascote. ");

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else if (decimaSegundaDecisaoSudeste.equals("nao")) {
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                        System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao Sudeste, possui uma camiseta branca e preta, se localiza em Minas Gerais e nao possui o jogador 'Hulk' em seu elenco. ");

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }



                                } else if (decimaPrimeiraDecisaoSudeste.equals("nao")) {// Botafogo, Corinthians, Santos, Vasco
                                    //codigo valido caso oposto do primeiro

                                    System.out.println();
                                    System.out.println("Certo... Entao seu time possui as cores Branca e Preta e nao e de Minas Gerais... ");
                                    System.out.println("Seu time e do estado do Rio de Janeiro (sim/nao) ?");
                                    System.out.print("R: ");
                                    String decimaQuartaDecisao = leitor.nextLine();

                                    if (decimaQuartaDecisao.equals("sim")) { //------------ Vasco, Botafogo
                                        //código

                                        System.out.println();
                                        System.out.println("Certo...");
                                        System.out.println("Tenho dois palpites em mente. ");
                                        System.out.println("Em 1998 este time ganhou do poderoso Real Madrid (sim/nao) ?");
                                        System.out.print("R: ");
                                        String decimaQuintaDecisao = leitor.nextLine();

                                        if (decimaQuintaDecisao.equals("sim")) { //------------- Vasco
                                            //código

                                            System.out.println();
                                            System.out.println("Este time possui um estadio chamado Sao Januario (sim/nao) ?");
                                            System.out.print("R: ");
                                            String decimaSextaDecisao = leitor.nextLine();

                                            if (decimaSextaDecisao.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("Acredito que o seu time seja o :");
                                                System.out.println();
                                                System.out.println("Time: Vasco da Gama");
                                                System.out.println("Regiao: Sudeste");
                                                System.out.println("Fundacao: 1898");
                                                System.out.println("Mascote: Almirante");
                                                System.out.println("Estadio: Sao Januario");
                                                System.out.println("Cidade: Rio de Janeiro");

                                            } else if (decimaSextaDecisao.equals("nao")) {
                                                //codigo valido caso oposto do primeiro

                                                System.out.println();
                                                System.out.println("Desculpe..");
                                                System.out.println("Mas as suas respostas possuem divergencias. ");
                                                System.out.println("Atualmente nao existe um time que jogue na Serie A, seja da regiao sudeste, tenha a camisa preta e branca, nao reside em Minas Gerais , tenha ganhado do Real Madrid em 1998 e nao tenha um estadio chamado Sao Januario. ");

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else if (decimaQuintaDecisao.equals("nao")) {//---------------------- Botafogo
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Este time possui um estadio chamado Nilton Santos (sim/nao) ? ");
                                            System.out.print("R: ");
                                            String decimaSextaDecisao = leitor.nextLine();

                                            if (decimaSextaDecisao.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("Seu time possui um cachorro(Biriba) como mascote (sim/nao) ?");
                                                System.out.print("R: ");
                                                String decimaSetimaDecisao = leitor.nextLine();

                                                if (decimaSetimaDecisao.equals("sim")) {
                                                    //código

                                                    System.out.println();
                                                    System.out.println("Acredito que seu time seja o: ");
                                                    System.out.println();
                                                    System.out.println("Time: Botafogo");
                                                    System.out.println("Regiao: Sudeste");
                                                    System.out.println("Fundacao: 1904");
                                                    System.out.println("Mascote: Cachorro(Biriba)");
                                                    System.out.println("Estadio: Nilton Santos");
                                                    System.out.println("Localizacao: Rio de Janeiro");

                                                } else if (decimaSetimaDecisao.equals("nao")) {
                                                    //codigo valido caso oposto do primeiro

                                                    System.out.println();
                                                    System.out.println("Desculpe mas suas respostas possuem divergencias. ");
                                                    System.out.println("Atualmente nao existe um time que jogue a serie A, e da regiao Sudeste, possui as cores branca e preta em sua camiseta, nao e de Minas Gerais, se localiza no Rio de Janeiro, possui o estadio Nilson Santos, e nao possui o mascote de um cachorro(Biriba). ");

                                                } else {
                                                    //código falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                }

                                            } else if (decimaSextaDecisao.equals("nao")) {
                                                //codigo valido caso oposto do primeiro

                                                System.out.println();
                                                System.out.println("Desculpe mas suas respostas possuem divergencias. ");
                                                System.out.println("Atualmente nao existe um time que jogue a serie A, e da regiao Sudeste, possui as cores branca e preta em sua camiseta, nao e de Minas Gerais, se localiza no Rio de Janeiro, nao ganhou do Real Madrid em 98 e nao possua o estadio Nilson Santos. ");

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else if (decimaQuartaDecisao.equals("nao")) {
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Certo... Entao seu time nao e do Rio de Janeiro...");
                                        System.out.println("Seu time e de Sao Paulo ? ");
                                        System.out.print("R: ");
                                        String decimaOitavaDecisao = leitor.nextLine();

                                        if (decimaOitavaDecisao.equals("sim")) {//--------- Santos e Corinthians
                                            //código

                                            System.out.println();
                                            System.out.println("Seu time possui um animal aquatico(orca) como mascote (sim/nao) ?");
                                            System.out.print("R: ");
                                            String decimaNonaDecisao = leitor.nextLine();

                                            if (decimaNonaDecisao.equals("sim")) {//----------------------------- Santos
                                                //código

                                                System.out.println();
                                                System.out.println("Seu time possui um estadio chamado Vila Belmiro (sim/nao) ?");
                                                System.out.print("R: ");
                                                String vigesimaDecisaoSudeste = leitor.nextLine();

                                                if (vigesimaDecisaoSudeste.equals("sim")) {
                                                    //código

                                                    System.out.println();
                                                    System.out.println("Seu time descobriu o famoso jogador de futebol chamado Neymar Junior (sim/nao) ?");
                                                    System.out.print("R: ");
                                                    String vegisimaPrimeiraDecisao = leitor.nextLine();

                                                    if (vegisimaPrimeiraDecisao.equals("sim")) {
                                                        //código

                                                        System.out.println();
                                                        System.out.println("Seu time possui Libertadores e Mundial (sim/nao) ?");
                                                        System.out.print("R: ");
                                                        String vegisemaSegundaDecisao = leitor.nextLine();

                                                        if (vegisemaSegundaDecisao.equals("sim")) {
                                                            //código

                                                            System.out.println();
                                                            System.out.println("Acredito que seu time seja o: ");
                                                            System.out.println();
                                                            System.out.println("Time: Santos");
                                                            System.out.println("Fundacao: 1912");
                                                            System.out.println("Mascote: Orca");
                                                            System.out.println("Estadio: Vila Belmiro");
                                                            System.out.println("Cidade: Santos-SP");

                                                        } else if (vegisemaSegundaDecisao.equals("nao")) {
                                                            //codigo valido caso oposto do primeiro

                                                            System.out.println();
                                                            System.out.println("Desculpe mas as suas respostas possuem divergencias.");
                                                            System.out.println("Atualmente nao existe um time que joga na serie A, faz parte da regiao sudeste, reside em Sao Paulo, possui um animal aquatico como mascote, possui um estadio chamado Vila Belmiro, descobriu o Neymar, e nao possui Libertadores nem Mundial.");
                                                            System.out.println();
                                                            System.out.println("Mesmo sua resposta possuindo divergencias, acredito que seu time seja o: ");
                                                            System.out.println();
                                                            System.out.println("Time: Santos");
                                                            System.out.println("Regiao: Sudeste");
                                                            System.out.println("Fundacao: 1912");
                                                            System.out.println("Mascote: Orca");
                                                            System.out.println("Estadio: Vila Belmiro");
                                                            System.out.println("Cidade: Santos-SP");

                                                        } else {
                                                            //código falso

                                                            System.out.println();
                                                            System.out.println("Desculpe, ");
                                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                            System.out.println("Obrigado e volte sempre !!");

                                                        }

                                                    } else if (vegisimaPrimeiraDecisao.equals("nao")) {
                                                        //codigo valido caso oposto do primeiro

                                                        System.out.println();
                                                        System.out.println("Desculpe, suas respostas possuem divergencias.");
                                                        System.out.println("Atualmente nao existe time que joga na serie A, faz parte da regiao Sudeste, possui em sua camisa as cores preta e branca, reside em Sao Paulo, possui um animal aquatico(orca) como mascote, possui um estadio chamado Vila Belmiro e nao tenha descoberto o Neymar");
                                                        System.out.println();
                                                        System.out.println("Mesmo sua resposta possuindo divergencias, acredito que seu time seja o: ");
                                                        System.out.println();
                                                        System.out.println("Time: Santos");
                                                        System.out.println("Regiao: Sudeste");
                                                        System.out.println("Fundacao: 1912");
                                                        System.out.println("Mascote: Orca");
                                                        System.out.println("Estadio: Vila Belmiro");
                                                        System.out.println("Cidade: Santos-SP");

                                                    } else {
                                                        //código falso

                                                        System.out.println();
                                                        System.out.println("Desculpe, ");
                                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                        System.out.println("Obrigado e volte sempre !!");

                                                    }

                                                } else if (vigesimaDecisaoSudeste.equals("nao")) {
                                                    //codigo valido caso oposto do primeiro

                                                    System.out.println();
                                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias. ");
                                                    System.out.println("Atualmente nao existe um time que joga na serie A, faz parte da regiao Sudeste, possui as cores branca e preta em sua camiseta, reside em Sao Paulo, possui uma orca como mascote e nao possua um estadio chamado Vila Belmiro.");

                                                } else {
                                                    //código falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                }

                                            } else if (decimaNonaDecisao.equals("nao")) {//---------------- -Corinthians
                                                //codigo valido caso oposto do primeiro

                                                System.out.println();
                                                System.out.println("Seu time possui um mosqueteiro como mascote (sim/nao) ?");
                                                System.out.print("R: ");
                                                String vigesimaSegundaDecisao = leitor.nextLine();

                                                if (vigesimaSegundaDecisao.equals("sim")) {//---------Corinthians
                                                    //código

                                                    System.out.println();
                                                    System.out.println("Seu time possui um Estadio chamado Neo Quimica Arena (sim/nao) ?");
                                                    System.out.print("R: ");
                                                    String vigesimaTerceiraDecisao = leitor.nextLine();

                                                    if (vigesimaTerceiraDecisao.equals("sim")) {
                                                        //código

                                                        System.out.println();
                                                        System.out.println("Acredito que o time na qual esteja pensando seja o: ");
                                                        System.out.println();
                                                        System.out.println("Time: Corinthians");
                                                        System.out.println("Regiao: Sudeste");
                                                        System.out.println("Fundacao: 1910");
                                                        System.out.println("Estadio: Neo Quimica Arena");
                                                        System.out.println("Cidade: Sao Paulo-SP");

                                                    } else if (vigesimaTerceiraDecisao.equals("nao")) {
                                                        //codigo valido caso oposto do primeiro

                                                        System.out.println();
                                                        System.out.println("Desculpe mas as suas respostas possuem divergencias.");
                                                        System.out.println("Atualmente nao existe um time que joga na serie A, faz parte da regiao Sudeste, possui as cores branca e preta em sua camiseta, reside em Sao Paulo, possui um mosqueteiro como mascote e nao possui um estadio chamado Neo Quimica Arena.");
                                                        System.out.println();
                                                        System.out.println("Mesmo com as divergencias, acredito que o time na qual esteja pensando seja o: ");
                                                        System.out.println();
                                                        System.out.println("Time: Corinthians");
                                                        System.out.println("Regiao: Sudeste");
                                                        System.out.println("Fundacao: 1910");
                                                        System.out.println("Estadio: Neo Quimica Arena");
                                                        System.out.println("Cidade: Sao Paulo-SP");

                                                    } else {
                                                        //código falso

                                                        System.out.println();
                                                        System.out.println("Desculpe, ");
                                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                        System.out.println("Obrigado e volte sempre !!");

                                                    }

                                                } else if (vigesimaSegundaDecisao.equals("nao")) {
                                                    //codigo valido caso oposto do primeiro

                                                    System.out.println();
                                                    System.out.println("Desculpe mas as suas respostas possuem divergencias.");
                                                    System.out.println("Atualmente nao existe time que jogue na serie A, faz parte da regiao sudeste, possui as cores branca e preta, reside em Sao Paulo nao possua uma orca como mascote nem um Mosqueteiro.");

                                                } else {
                                                    //código falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                }

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else if (decimaOitavaDecisao.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                            System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao sudeste, possui a cor da camisa preta e branca, nao resida em Minas Gerais nem no Rio de Janeiro e nem em Sao Paulo.");

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else if (decimaDecisaoSudeste.equals("nao")) { //times da serie A que nao possuem a camiseta branca e preta
                                //codigo valido caso oposto do primeiro

                                System.out.println();
                                System.out.println("Seu time possui o recorde de 'goleiro que fez mais gols' no Brasil (sim/nao) ? ");
                                System.out.print("R: ");
                                String vigesimaTerceiraDecisaoSudeste = leitor.nextLine();

                                if (vigesimaTerceiraDecisaoSudeste.equals("sim")) { //------------------------- Sao Paulo
                                    //código

                                    System.out.println();
                                    System.out.println("Seu time possui um mascote chamado Santo Paulo (sim/nao) ? ");
                                    System.out.print("R: ");
                                    String vigesimaQuartaDecisaoSudeste = leitor.nextLine();

                                    if (vigesimaQuartaDecisaoSudeste.equals("sim")) { ///--------------------- Sao Paulo
                                        //código

                                        System.out.println();
                                        System.out.println("Acredito que o time que esteja pensando seja o: ");
                                        System.out.println();
                                        System.out.println("Time: Sao Paulo");
                                        System.out.println("Regiao: Sudeste");
                                        System.out.println("Fundacao: 1930");
                                        System.out.println("Mascote: Santo Paulo");
                                        System.out.println("Estadio: Cicero Pompeu de Toledo/Morumbi");
                                        System.out.println("Cidade: Sao Paulo-SP");

                                    } else if (vigesimaQuartaDecisaoSudeste.equals("nao")) {
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                        System.out.println("Atualmente nao existe um time que joga na serie A, faz parte da regiao Sudeste, possui o record de 'goleiro que fez mais gols' e nao possua o mascote o 'Santo Paulo como mascote.' ");

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else if (vigesimaTerceiraDecisaoSudeste.equals("nao")) {// ------------IMPORTANTE escolher outro time
                                    //codigo valido caso oposto do primeiro

                                    System.out.println();
                                    System.out.println("Estou pensando...");
                                    System.out.println("Seu time possui as cores preta e vermelha em sua camisa (sim/nao) ?");
                                    System.out.print("R: ");
                                    String vigesimaQuartaDecisao = leitor.nextLine();

                                    if (vigesimaQuartaDecisao.equals("sim")) {//------------------------------- FLAMENGO
                                        //código

                                        System.out.println();
                                        System.out.println("O time na qual esta pensando possui um urubu como mascote (sim/nao) ?");
                                        System.out.print("R: ");
                                        String vigesimaQuintaDecisao = leitor.nextLine();

                                        if (vigesimaQuintaDecisao.equals("sim")) {//--------------------------- FLAMENGO
                                            //código

                                            System.out.println();
                                            System.out.println("Seu time possui um jogador famoso chamado 'Gabigol' em seu elenco (sim/nao) ? ");
                                            System.out.print("R: ");
                                            String vigesimaSextaDecisao = leitor.nextLine();

                                            if (vigesimaSextaDecisao.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("Acredito que seu time seja o: ");
                                                System.out.println();
                                                System.out.println("Time: Flamengo");
                                                System.out.println("Regiao: Sudeste");
                                                System.out.println("Fundacao: 1895");
                                                System.out.println("Mascote: Urubu");
                                                System.out.println("Estadio: Maracana");
                                                System.out.println("Cidade: Rio de Janeiro-RJ");

                                            } else if (vigesimaSextaDecisao.equals("nao")) {
                                                //codigo valido caso oposto do primeiro

                                                System.out.println();
                                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                                System.out.println("Atualmente, nao existe um time que jogue na serie A, na regiao Sudeste, possui as cores vermelha e preta, possui um urubu como mascote e nao possua o jogador chamado 'Gabigol' em seu elenco.");

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else if (vigesimaQuintaDecisao.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                            System.out.println("Atualmente nao existe um time que jogue na serie A, faz parte da regiao Sudeste, possui as cores preta e vermelha em sua camisa e nao possua um urubu como mascote.");

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else if (vigesimaQuartaDecisao.equals("nao")) {//---------------------- OUTRO TIME
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Seu time possui a marca de um energetico em seu nome (sim/nao) ?");
                                        System.out.print("R: ");
                                        String vigesimaOitavaDecisaoSudeste = leitor.nextLine();

                                        if (vigesimaOitavaDecisaoSudeste.equals("sim")) {
                                            //código

                                            System.out.println();
                                            System.out.println("Seu time possui a cor da camiseta as cores azul e branca (sim/nao) ?");
                                            System.out.print("R: ");
                                            String vigesimaNonaDecisaoSudeste = leitor.nextLine();

                                            if (vigesimaNonaDecisaoSudeste.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                                System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao Sudeste, tenha o nome de uma marca de energetico e utilize as cores azul e branca em sua camisa. ");

                                            } else if (vigesimaNonaDecisaoSudeste.equals("nao")) {
                                                //codigo valido caso oposto do primeiro

                                                System.out.println();
                                                System.out.println("Seu time possui um estadio chamado Nabi Abi Chedid (sim/nao) ?");
                                                System.out.print("R: ");
                                                String trigesimaDecisaoSudeste = leitor.nextLine();

                                                if (trigesimaDecisaoSudeste.equals("sim")) {
                                                    //código

                                                    System.out.println();
                                                    System.out.println("Acredito que seu time seja o:");
                                                    System.out.println();
                                                    System.out.println("Time: Bragantino");
                                                    System.out.println("Fundacao: 1928");
                                                    System.out.println("Regiao: Sudeste");
                                                    System.out.println("Mascote: Touro");
                                                    System.out.println("Estadio: Estadio Nabi Abi Chedid");
                                                    System.out.println("Cidade: Braganca Paulista");

                                                } else if (trigesimaDecisaoSudeste.equals("nao")) {
                                                    //codigo valido caso oposto do primeiro

                                                    System.out.println();
                                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                                    System.out.println("Atualmente nao existe um time que jogue na serie A, e da regiao Sudeste, tenha o nome de uma marca de energetico, utilize as cores azul e branca em sua camisa e nao tenha um estadio chamado Nabi Abi Chedid");

                                                } else {
                                                    //código falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                }

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else if (vigesimaOitavaDecisaoSudeste.equals("nao")) { //--------Fluminense, Palmeiras
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Seu time possui um estadio chamado 'Allianz Parque' (sim/nao) ? ");
                                            System.out.print("R: ");
                                            String trigesimaPrimeiraDecisaoSudeste = leitor.nextLine();

                                            if (trigesimaPrimeiraDecisaoSudeste.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("Seu time possui a camiseta principal a cor branca e vermelha (sim/nao) ?");
                                                System.out.print("R: ");
                                                String trigesimaSegundaDecisaoSudeste = leitor.nextLine();

                                                if (trigesimaSegundaDecisaoSudeste.equals("sim")) {
                                                    //código

                                                    System.out.println();
                                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias (sim/nao) ?");
                                                    System.out.println("Atualmente nao existe um time que joga na serie A, reside na regiao Sudeste, possui um estadio chamado 'Allianz Parque' e possua as cores branca e vermelha em sua camiseta.");

                                                } else if (trigesimaSegundaDecisaoSudeste.equals("nao")) {
                                                    //codigo valido caso oposto do primeiro

                                                    System.out.println();
                                                    System.out.println("Seu time possui um porco como mascote (sim/nao) ? ");
                                                    System.out.print("R: ");
                                                    String trigesimaTerceiraDecisaoSudeste = leitor.nextLine();

                                                    if (trigesimaTerceiraDecisaoSudeste.equals("sim")) {
                                                        //código

                                                        System.out.println();
                                                        System.out.println("Acredito que o time que esteja pensando seja o :");
                                                        System.out.println();
                                                        System.out.println("Time: Palmeiras");
                                                        System.out.println("Regiao: Sudeste");
                                                        System.out.println("Fundacao: 1914");
                                                        System.out.println("Mascote: Porco");
                                                        System.out.println("Estadio: Allianz Parque");
                                                        System.out.println("Cidade: Sao Paulo-SP");

                                                    } else if (trigesimaTerceiraDecisaoSudeste.equals("nao")) {
                                                        //codigo valido caso oposto do primeiro

                                                        System.out.println();
                                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                                        System.out.println("Atualmente nao existe um time que joga na serie A, reside na regiao Sudeste, tenha um estadio chamado 'Allianz Parque', nao possua uma camiseta da cor branca e vermelha e nem um porco como mascote.");

                                                    } else {
                                                        //código falso

                                                        System.out.println();
                                                        System.out.println("Desculpe, ");
                                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                        System.out.println("Obrigado e volte sempre !!");

                                                    }

                                                } else {
                                                    //código falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                }

                                            } else if (trigesimaPrimeiraDecisaoSudeste.equals("nao")) {//-------------Fluminense
                                                //codigo valido caso oposto do primeiro

                                                System.out.println();
                                                System.out.println("O time na qual esteja pensando possui as cores branco, bordo e verde em seu brasao e camiseta (sim/nao) ?");
                                                System.out.print("R: ");
                                                String trigesimaQuartaDecisaoSudeste = leitor.nextLine();

                                                if (trigesimaQuartaDecisaoSudeste.equals("sim")) {
                                                    //código

                                                    System.out.println();
                                                    System.out.println("Seu time possui mundial (sim/nao) ? ");
                                                    System.out.print("R: ");
                                                    String trigesimaQuintaDecisaoSudeste = leitor.nextLine();

                                                    if (trigesimaQuintaDecisaoSudeste.equals("sim")) {
                                                        //código

                                                        System.out.println();
                                                        System.out.println("Desculpe, suas respostas possuem divergencias.");
                                                        System.out.println("Atualmente nao existe um time que jogue na serie A, reside na regiao sudeste, possui as cores branco/bordo/verde em sua identidade visual e tenha ganhado um mundial.");

                                                    } else if (trigesimaQuintaDecisaoSudeste.equals("nao")) {
                                                        //codigo valido caso oposto do primeiro

                                                        System.out.println();
                                                        System.out.println("Certo...");
                                                        System.out.println("O seu time possui um mascote apelidado de 'Cartola' (sim/nao) ? ");
                                                        System.out.print("R: ");
                                                        String trigesimaSextaDecisaoSudeste = leitor.nextLine();

                                                        if (trigesimaSextaDecisaoSudeste.equals("sim")) {
                                                            //código

                                                            System.out.println();
                                                            System.out.println("O time que esta pensando acredito que seja o: ");
                                                            System.out.println();
                                                            System.out.println("Time: Fluminense");
                                                            System.out.println("Regiao: Sudeste");
                                                            System.out.println("Fundacao: 1902");
                                                            System.out.println("Mascote: Cartola");
                                                            System.out.println("Estadio: Maracana");
                                                            System.out.println("Cidade: Rio de Janeiro-RJ");

                                                        } else if (trigesimaSextaDecisaoSudeste.equals("nao")) {
                                                            //codigo valido caso oposto do primeiro

                                                            System.out.println();
                                                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                                            System.out.println("Atualmente, nao existe um time que jogue na serie A, resida na regiao Sudeste, possua as cores branco, bordo e verde em sua identidade visual, nao possua um mundial e nao tenha um mascote apelidado de 'Cartola'. ");

                                                            System.out.println();
                                                            System.out.println("Mesmo suas respostas esteja possuindo divergencias, acredito que o time que esteja pensando seja o: ");
                                                            System.out.println();
                                                            System.out.println("Time: Fluminense");
                                                            System.out.println("Regiao: Sudeste");
                                                            System.out.println("Fundacao: 1902");
                                                            System.out.println("Mascote: Cartola");
                                                            System.out.println("Estadio: Maracana");
                                                            System.out.println("Cidade: Rio de Janeiro-RJ");

                                                        } else {
                                                            //código falso

                                                            System.out.println();
                                                            System.out.println("Desculpe, ");
                                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                            System.out.println("Obrigado e volte sempre !!");

                                                        }

                                                    } else {
                                                        //código falso

                                                        System.out.println();
                                                        System.out.println("Desculpe, ");
                                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                        System.out.println("Obrigado e volte sempre !!");

                                                    }

                                                } else if (trigesimaQuartaDecisaoSudeste.equals("nao")) {
                                                    //codigo valido caso oposto do primeiro

                                                    System.out.println();
                                                    System.out.println("Desculpe, mas todas as logicas foram atendidas na regiao sudeste.");
                                                    System.out.println("Acredito que esteja tentando me enganar ou resposdeu alguma resposta de maneira indevida e por isso nao achei o seu time.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                } else {
                                                    //código falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                }

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else {
                            //código falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else {
                        //código falso

                        System.out.println();
                        System.out.println("Desculpe, ");
                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                        System.out.println("Obrigado e volte sempre !!");

                    }

                    break;

                case "sul":
                    //Times serie A do sul(4):
                    //Athletico Paranaense
                    //Coritiba
                    //Gremio
                    //Internacional

                    System.out.println();
                    System.out.println("Ok, ja separei uma listinha de times que fazem parte da regiao Sul...");
                    System.out.println("O time possui um furacao como mascote (sim/nao) ?");
                    System.out.print("R: ");
                    String primeiraDecisaoSul = leitor.nextLine();

                    if (primeiraDecisaoSul.equals("sim")) {
                        //código

                        System.out.println();
                        System.out.println("Ok, tenho um time em mente...");
                        System.out.println("O time ja ganhou uma libertadores (sim/nao) ?");
                        System.out.print("R: ");
                        String segundaDecisaoSul = leitor.nextLine();

                        if (segundaDecisaoSul.equals("sim")) {
                            //código

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                            System.out.println("Atualmente nao existe um time sulista que jogue a serie A, possui um furacao como mascote e possui um titulo da Libertadores. ");


                        } else if (segundaDecisaoSul.equals("nao")) { //Athletico Paranaense
                            //código caso nao

                            System.out.println();
                            System.out.println("Certo...");
                            //Thread.sleep(5000);
                            System.out.println("Seu time esta lozalizado em Curitiba (sim/nao) ?");
                            System.out.print("R: ");
                            String terceiraDecisaoSul = leitor.nextLine();

                            if (terceiraDecisaoSul.equals("sim")) {
                                //código

                                System.out.println();
                                System.out.println("Certo...");
                                //Thread.sleep(5000);
                                System.out.println("Eu acho que seu time e o: ");
                                System.out.println();
                                System.out.println("Time: Athletico Paranaense");
                                System.out.println("Regiao: Sul");
                                System.out.println("Fundacao: 1924");
                                System.out.println("Mascote: Furacao");
                                System.out.println("Estadio: Joaquim Guimaraes");
                                System.out.println("Cidade: Curitiba");

                            } else if (terceiraDecisaoSul.equals("nao")) {
                                //código caso nao

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe um clube sulista que joga na serie A, possui um furacao como mascote, nao tenha ganhado uma libertadores e que nao resida em Curitiba.");

                            } else {

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else {

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else if (primeiraDecisaoSul.equals("nao")) {
                        //código caso nao

                        System.out.println();
                        System.out.println("Certo...");
                        //Thread.sleep(5000);
                        System.out.println("Entao o time na qual esta pensando joga na serie A, reside na regiao Sul e nao possui um furacao como mascote");
                        //Thread.sleep(5000);
                        System.out.println("Ok, entendi...");
                        System.out.println();
                        System.out.println("Este time possui um Estadio denomidado Couto Pereira (sim/nao) ? ");
                        System.out.print("R: ");
                        String quartaDecisaoSul = leitor.nextLine();

                        if (quartaDecisaoSul.equals("sim")) {
                            //código

                            System.out.println();
                            //Thread.sleep(5000);
                            System.out.println("Certo...");
                            System.out.println("Tenho um palpite");
                            System.out.println("Seu time possui um mascote chamado 'Vovo Coxa' (sim/nao) ? ");
                            System.out.print("R: ");
                            String quintaDecisaoSul = leitor.nextLine();

                            if (quintaDecisaoSul.equals("sim")) { //-------------------CORITIBA-----------------------------
                                //código

                                System.out.println();
                                //Thread.sleep(5000);
                                System.out.println("Certo...");
                                System.out.println("Entao neste caso suponho que seja o: ");
                                System.out.println();
                                System.out.println("Time: Coritiba");
                                System.out.println("Regiao: Sul");
                                System.out.println("Fundacao: 1909");
                                System.out.println("Mascote: Vovo Coxa");
                                System.out.println("Estadio: Couto Pereira");
                                System.out.println("Cidade: Curitiba-PR");

                            } else if (quintaDecisaoSul.equals("nao")) {
                                //código caso nao

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe um time sulista que participe da serie A, que possua um estadio denominado Couto Pereira e que nao tem um mascote chamado 'Vovo Coxa'.");


                            }

                        } else if ((quartaDecisaoSul.equals("nao"))) {//nao possui estadio denominado couto pereira
                            //código caso nao

                            System.out.println();
                            System.out.println("Certo...");
                            System.out.println("Seu time e de Porto Alegre (sim/nao) ?");
                            System.out.print("R: ");
                            String sextaDecisaoSul = leitor.nextLine();

                            if (sextaDecisaoSul.equals("sim")) {//-----------------Inter ou Gremio--------------------------
                                //código

                                System.out.println();
                                System.out.println("Este time e famoso (sim/nao) ?");
                                System.out.print("R: ");
                                String setimaDecisaoSul = leitor.nextLine();

                                if (setimaDecisaoSul.equals("sim")) {
                                    //código

                                    System.out.println();
                                    System.out.println("Hmm... Essa esta dificil...");
                                    System.out.println("Seu time possui uma rivalidade grande com outro time do mesmo estado (sim/nao) ? ");
                                    System.out.print("R: ");
                                    String oitavaDecisaoSul = leitor.nextLine();

                                    if (oitavaDecisaoSul.equals("sim")) {
                                        //código

                                        System.out.println();
                                        System.out.println("Este time possui as cores azul, preta, branca em sua camiseta (sim/nao) ? ");
                                        System.out.print("R: ");
                                        String nonaDecisaoSul = leitor.nextLine();

                                        if (nonaDecisaoSul.equals("sim")) {//---------------------GREMIO--------------------
                                            //código

                                            System.out.println();
                                            System.out.println("O time na qual voce esta pensando possui um estadio chamado de 'Arena do Gremio' (sim/nao) ? ");
                                            System.out.print("R: ");
                                            String decimaDecisaoSul = leitor.nextLine();

                                            if (decimaDecisaoSul.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("O time na qual voce esta pensando: ");
                                                System.out.println();
                                                System.out.println("Time: Gremio");
                                                System.out.println("Regiao: Sul");
                                                System.out.println("Mascote: Mosqueteiro");
                                                System.out.println("Nome do Estadio: Arena do Gremio");
                                                System.out.println("Ano Fundacao: 1903");
                                                System.out.println("Cidade: Porto Alegre-RS");

                                            } else if (decimaDecisaoSul.equals("nao")) {
                                                //código caso nao

                                                System.out.println();
                                                System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                                System.out.println("Atualmente nao existe um time sulista que jogue na serie A, nao possua um mascote de um furacao, nao possui um estadio Couto Pereira, seja um time famoso, que possui um rival no mesmo estado, possui uma camiseta azul, branca e preta e que nao possua um estadio chamado 'Arena do Gremio'.");

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else if (nonaDecisaoSul.equals("nao")) {//----------------INTER-------------------
                                            //código caso nao

                                            System.out.println();
                                            System.out.println("Certo...");
                                            System.out.println("O seu time possui um Saci como mascote (sim/nao) ?");
                                            System.out.print("R: ");
                                            String decimaprimeiraDecisaoSul = leitor.nextLine();

                                            if (decimaprimeiraDecisaoSul.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("O Estadio do seu time fica as margens do lago Guaiba (sim/nao) ? ");
                                                System.out.print("R: ");
                                                String decimaPrimeiraDecisaoSul = leitor.nextLine();

                                                if (decimaPrimeiraDecisaoSul.equals("sim")) {
                                                    //código

                                                    System.out.println();
                                                    System.out.println("O time na qual voce esta pensando: ");
                                                    System.out.println();
                                                    System.out.println("Time: Internacional");
                                                    System.out.println("Regiao: Sul");
                                                    System.out.println("Fundacao: 1909");
                                                    System.out.println("Mascote: Saci");
                                                    System.out.println("Estadio: Beira-Rio");
                                                    System.out.println("Cidade: Porto Alegre-RS");

                                                } else if (decimaPrimeiraDecisaoSul.equals("nao")) {
                                                    //código caso nao

                                                    System.out.println();
                                                    System.out.println("Desculpe mas suas respostas possuem divergencias.");
                                                    System.out.println("Atualmente nao existe um time sulista que jogue na serie A, nao possua um mascote de um furacao, nao possui um estadio Couto Pereira, seja um time famoso, tenha um rival no mesmo estado, possua um Saci como mascote, e nao tenha o estadio as margens do lago Guaiba.");

                                                } else {
                                                    //código falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                }

                                            } else if (decimaprimeiraDecisaoSul.equals("nao")) {
                                                //código caso nao

                                                System.out.println();
                                                System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                                System.out.println("Atualmente nao existe um time sulista que jogue na serie A, nao possua um mascote de um furacao, nao possui um estadio Couto Pereira, seja um time famoso, tenha um rival no mesmo estado e nao possua um Saci como mascote");

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else if (oitavaDecisaoSul.equals("nao")) {
                                        //código caso nao

                                        System.out.println();
                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                        System.out.println("Atualmente nao existe um time sulista que jogue na serie A, nao possua um mascote de um furacao, nao possui um estadio chamado 'Couto Pereira', seja um time famoso e que nao tem um rival no mesmo estado");

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else if (setimaDecisaoSul.equals("nao")) {
                                    //código caso nao

                                    System.out.println();
                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                    System.out.println("Atualmente nao existe um time sulista que jogue na serie A, nao possua um mascote furacao e nao possui um estadio Couto Pereira e nao seja um time famoso");

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else if (sextaDecisaoSul.equals("nao")) {
                                //código caso nao

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                System.out.println("Atualmente nao existe um time sulista que jogue na serie A, nao possui um mascote furacao e nao possui um estadio Couto Pereira.");

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else {
                            //código falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }
                    } else {

                        System.out.println();
                        System.out.println("Desculpe, ");
                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                        System.out.println("Obrigado e volte sempre !!");

                    }

                    break;

                default:  //Digitou a regiao do pais de forma incompativel com as propostas

                    System.out.println();
                    System.out.println("Desculpe, ");
                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                    System.out.println("Obrigado e volte sempre !!");

            }
        } else if (serieA.equals("nao")) { //Apenas times da série B
            //código caso nao

            System.out.println();
            System.out.println("Certo...");
            System.out.println("Ja separei uma lista de times da serie B.");
            System.out.println();
            System.out.println("Seu time que joga na serie B, e de qual regiao do Brasil (norte/nordeste/centro-oeste/sudeste/sul) ?");
            System.out.print("R: ");
            String regiaoB = leitor.nextLine();

            switch (regiaoB) {
                case "norte": //times serie B do norte(0)

                    System.out.println();
                    System.out.println("Desculpe...");
                    System.out.println("Mas atualmente nao existe times do norte na serie A nem na serie B no campeonato brasileiro 2023.");

                    break;

                case "nordeste": //times serie B do nordeste(6)
                    //ABC ----------------------- FEITO
                    //CRB ----------------------- FEITO
                    //Ceara --------------------- FEITO
                    //Sampaio Correa ------------ FEITO
                    //Sport --------------------- FEITO
                    //Vitoria ------------------- FEITO

                    System.out.println();
                    System.out.println("Certo...");
                    System.out.println("Ja separei alguns times do nordeste para palpitar.");
                    System.out.println();
                    System.out.println("O nome do seu time sao as 3 primeiras letras do alfabeto (sim/nao) ?");
                    System.out.print("R: ");
                    String bPrimeiraDecisaoNordeste = leitor.nextLine();

                    if (bPrimeiraDecisaoNordeste.equals("sim")) {
                        //código

                        System.out.println();
                        System.out.println("Seu time possui um mascote de um elefante (sim/nao) ?");
                        System.out.print("R: ");
                        String bSegundaDecisaoNordeste = leitor.nextLine();

                        if (bSegundaDecisaoNordeste.equals("sim")) {
                            //código

                            System.out.println();
                            System.out.println("Acredito que seu time seja o: ");
                            System.out.println();
                            System.out.println("Time: ABC");
                            System.out.println("Fundacao: 1915");
                            System.out.println("Mascote: Elefante");
                            System.out.println("Estadio: Maria Lamas Farache");
                            System.out.println("Cidade: Natal");

                        } else if (bSegundaDecisaoNordeste.equals("nao")) {
                            //codigo valido caso oposto do primeiro

                            System.out.println();
                            System.out.println("Desculpe, mas atualmente suas respostas possuem divergencias.");
                            System.out.println("Atualmente, nao existe um time que jogue na serie B, reside no nordeste, possui as 3 primeira letras iniciais do alfabeto e nao possua um elefante como mascote.");

                        } else {
                            //código falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else if (bPrimeiraDecisaoNordeste.equals("nao")) {
                        //codigo valido caso oposto do primeiro

                        System.out.println();
                        System.out.println("Compreendo...");
                        System.out.println("O time na qual esteja pensando possui o nome do estadio 'Rei Pele' (sim/nao) ? ");
                        System.out.print("R: ");
                        String bTerceiraDecisaoNordeste = leitor.nextLine();

                        if (bTerceiraDecisaoNordeste.equals("sim")) { //---------------- CRB
                            //código

                            System.out.println();
                            System.out.println("O mascote do seu time e um pinguim (sim/nao) ?");
                            System.out.print("R: ");
                            String bQuartaDecisaoNordeste = leitor.nextLine();

                            if (bQuartaDecisaoNordeste.equals("sim")) {
                                //código

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                System.out.println("Atualmente nao existe um time na serie B, que resida no nordeste, possui um estadio chamado 'Rei Pele' e tem um mascote de um pinguim.");

                            } else if (bQuartaDecisaoNordeste.equals("nao")) {
                                //codigo valido caso oposto do primeiro

                                System.out.println();
                                System.out.println("Certo...");
                                System.out.println("Seu time se localiza na cidade de Maceio (sim/nao) ?");
                                System.out.print("R: ");
                                String bQuintaDecisaoNordeste = leitor.nextLine();

                                if (bQuintaDecisaoNordeste.equals("sim")) {
                                    //código

                                    System.out.println();
                                    System.out.println("Acredito que seu time seja o: ");
                                    System.out.println();
                                    System.out.println("Time: CRB");
                                    System.out.println("Fundacao: 1912");
                                    System.out.println("Mascote: Galo de Campina");
                                    System.out.println("Estadio: Rei Pele");
                                    System.out.println("Cidade: Maceio");

                                } else if (bQuintaDecisaoNordeste.equals("nao")) {
                                    //codigo valido caso oposto do primeiro

                                    System.out.println();
                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                    System.out.println("Atualmente nao existe um time que joga na serie B, reside no nordeste, possui o nome do estadio o rei Pele, nao tenha um pinguim como mascote e nao resida em Maceio");

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if (bTerceiraDecisaoNordeste.equals("nao")) {
                            //codigo valido caso oposto do primeiro

                            System.out.println();
                            System.out.println("Certo...");
                            System.out.println("Seu time possui um mascote chamado 'Vovo' (sim/nao) ? ");
                            System.out.print("R: ");
                            String bSextaDecisaoNordeste = leitor.nextLine();

                            if (bSextaDecisaoNordeste.equals("sim")) { //--------------------- Ceara
                                //código

                                System.out.println();
                                System.out.println("Hmmm... Entendi");
                                System.out.println("O time na qual esteja pensando possui um estadio chamado 'Ilha do Retiro' (sim/nao) ? ");
                                System.out.print("R: ");
                                String bSetimaDecisaoNordeste = leitor.nextLine();

                                if (bSetimaDecisaoNordeste.equals("sim")) {
                                    //código

                                    System.out.println();
                                    System.out.println("Desculpe, mas suas respostas possuem divergencias");
                                    System.out.println("Atualmente nao existe um time que joga na serie B, reside no nordeste, possui o 'Vovo' como mascote e possui o estadio chamado 'Ilha do Retiro'.");

                                } else if (bSetimaDecisaoNordeste.equals("nao")) {
                                    //codigo valido caso oposto do primeiro

                                    System.out.println();
                                    System.out.println("Acredito que esteja pensando e o: ");
                                    System.out.println();
                                    System.out.println("Time: Ceara");
                                    System.out.println("Fundacao: 1914");
                                    System.out.println("Mascote: Vovo");
                                    System.out.println("Estadio: Arena Castelao");
                                    System.out.println("Cidade: Fortaleza");

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else if (bSextaDecisaoNordeste.equals("nao")) { //----------------- OUTROS TIMES
                                //codigo valido caso oposto do primeiro

                                System.out.println();
                                System.out.println("Certo...");
                                System.out.println("O time na qual esteja pensando possui um tubarao como mascote (sim/nao) ?");
                                System.out.print("R: ");
                                String bSetimaDecisaoNordeste = leitor.nextLine();

                                if (bSetimaDecisaoNordeste.equals("sim")) { //Sampaio Correa
                                    //código

                                    System.out.println();
                                    System.out.println("O nome da cidade do seu time e 'Sao Miguel dos Milagres' (sim/nao) ?");
                                    System.out.print("R: ");
                                    String bOitavaDecisaoNordeste = leitor.nextLine();

                                    if (bOitavaDecisaoNordeste.equals("sim")) {
                                        //código

                                        System.out.println();
                                        System.out.println("Desculpe mas as suas respostas possuem divergencias.");
                                        System.out.println("Atualmente nao existe um time que joga na serie B, reside no nordeste, possui um tubarao como mascote e se localiza na cidade 'Sao Miguel dos Milagres'.");

                                    } else if (bOitavaDecisaoNordeste.equals("nao")) {
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Entendi...");
                                        System.out.println("O time na qual esteja pensando possui o estadio chamado 'Estadio Governador Joao Castelo' (sim/nao) ?");
                                        System.out.print("R: ");
                                        String bNonaDecisaoNordeste = leitor.nextLine();

                                        if (bNonaDecisaoNordeste.equals("sim")) {
                                            //código

                                            System.out.println();
                                            System.out.println("Acredito que seu time seja o: ");
                                            System.out.println();
                                            System.out.println("Time: Sampaio Correa");
                                            System.out.println("Regiao: Nordeste");
                                            System.out.println("Fundacao: 1923");
                                            System.out.println("Mascote: Tubarao");
                                            System.out.println("Estadio: Estadio Governador Joao Castelo(Castelao)");

                                        } else if (bNonaDecisaoNordeste.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                            System.out.println("Atualmente nao existe um time que atua na serie B, reside no nordeste, possui um mascote de um tubarao, nao seja da cidade 'Sao Miguel dos Milagres' e nao tenha um estadio chamado 'Estadio Governador Joao Castelo' ");

                                        } else {
                                            //código falso

                                            System.out.println("Desculpe...");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");
                                        }

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe...");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else if (bSetimaDecisaoNordeste.equals("nao")) { //OUTROS TIMES - SPORT OU VITORIA
                                    //codigo valido caso oposto do primeiro

                                    System.out.println();
                                    System.out.println("Entendi....");
                                    System.out.println("O time na qual esteja pensando possui um leao dourado em seu brasao/escudo (sim/nao) ?");
                                    System.out.print("R: ");
                                    String bDecimaDecisaoNordeste = leitor.nextLine();

                                    if (bDecimaDecisaoNordeste.equals("sim")) { // SPORT
                                        //código

                                        System.out.println();
                                        System.out.println("Seu time possui libertadores (sim/nao) ?");
                                        System.out.print("R: ");
                                        String bDecimaPrimeiraDecisaoNordeste = leitor.nextLine();

                                        if (bDecimaPrimeiraDecisaoNordeste.equals("sim")) {
                                            //código

                                            System.out.println();
                                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                            System.out.println("Atualmente nao existe um time que jogue na serie B, reside no nordeste, tenha um leao dourado em seu escudo/brasao e possui titulo de libertadores.");

                                        } else if (bDecimaPrimeiraDecisaoNordeste.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("O time e da cidade de Recife (sim/nao) ?");
                                            System.out.print("R: ");
                                            String bDecimaSegundaDecisaoNordeste = leitor.nextLine();

                                            if (bDecimaSegundaDecisaoNordeste.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("Acredito que esteja pensando no: ");
                                                System.out.println();
                                                System.out.println("Time: Sport");
                                                System.out.println("Regiao: Nordeste");
                                                System.out.println("Fundacao: 1905");
                                                System.out.println("Mascote: Leao");
                                                System.out.println("Estadio: Ilha do Retiro");
                                                System.out.println("Cidade: Recife");

                                            } else if (bDecimaSegundaDecisaoNordeste.equals("nao")) {
                                                //codigo valido caso oposto do primeiro

                                                System.out.println();
                                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                                System.out.println("Atualmente, nao existe um time que jogue na serie B, reside no nordeste, possui um leao dourado em seu escudo/brasao, nao tenha libertadores e nao resida em Recife.");

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else if (bDecimaDecisaoNordeste.equals("nao")) { // ---------------------- VITORIA
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("O seu time se localiza na Bahia (sim/nao) ?");
                                        System.out.print("R: ");
                                        String bDecimaTerceiraDecisao = leitor.nextLine();

                                        if (bDecimaTerceiraDecisao.equals("sim")) {
                                            //código

                                            System.out.println();
                                            System.out.println("Certo tenho um palpite em mente...");
                                            System.out.println("O time possui as cores branca, vermelha e preta em seu brasao/escudo (sim/nao) ?");
                                            System.out.print("R: ");
                                            String bDecimaQuartaDecisao = leitor.nextLine();

                                            if (bDecimaQuartaDecisao.equals("sim")) {
                                                //código

                                                System.out.println();
                                                System.out.println("Entendi !!");
                                                System.out.println("Seu time possui um papagaio como mascote (sim/nao) ?");
                                                System.out.print("R: ");
                                                String bDecimaQuintaDecisao = leitor.nextLine();

                                                if (bDecimaQuintaDecisao.equals("sim")) {
                                                    //código

                                                    System.out.println();
                                                    System.out.println("Desculpe mas as suas respostas possuem divergencias");
                                                    System.out.println("Atualmente nao existe um time que joga na seria A, resida no nordeste, da Bahia e nao possua as cores branca, vermelha e preta");

                                                } else if (bDecimaQuintaDecisao.equals("nao")) {
                                                    //codigo valido caso oposto do primeiro

                                                    System.out.println();
                                                    System.out.println("Acredito que seu time seja o: ");
                                                    System.out.println();
                                                    System.out.println("Time: Vitoria");
                                                    System.out.println("Regiao: Nordeste");
                                                    System.out.println("Fundacao: 1899");
                                                    System.out.println("Mascote: Leao");
                                                    System.out.println("Estadio Barracao");
                                                    System.out.println("Cidade: Salvador-Bahia");

                                                } else {
                                                    //código falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");
                                                }

                                            } else if (bDecimaQuartaDecisao.equals("nao")) {
                                                //codigo valido caso oposto do primeiro

                                                System.out.println();
                                                System.out.println("Desculpe mas as suas respostas possuem divergencias");
                                                System.out.println("Atualmente nao existe um time que joga na seria A, resida no nordeste, da Bahia e nao possua as cores branca, vermelha e preta");

                                            } else {
                                                //código falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else if (bDecimaTerceiraDecisao.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Desculpe mas todas as logicas foram atingidas ");

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");
                                }

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else {
                            //código falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else {
                        //código falso

                        System.out.println();
                        System.out.println("Desculpe, ");
                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                        System.out.println("Obrigado e volte sempre !!");

                    }

                    break;

                case "centro-oeste": //times serie B do centro-oeste(2)
                    //Atlético Goianiense ------------ FEITO
                    //Vila Nova-GO ------------------- FEITO
                    System.out.println();
                    System.out.println("Certo...");
                    System.out.println("Atualmente existem apenas 2 times na serie B, que residem na regiao do Centro-Oeste ja separei uma serie de perguntas relacionado a eles.");
                    System.out.println();
                    System.out.println("Seu time possui um dragao como mascote (sim/nao) ? ");
                    System.out.print("R: ");
                    String bPrimeiraDescisaoCentroOeste = leitor.nextLine();

                    if (bPrimeiraDescisaoCentroOeste.equals("sim")) { //Atlético Goianiense
                        //codigo

                        System.out.println();
                        System.out.println("Certo...");
                        System.out.println("Seu time possui uma camiseta com o design(nao as cores) semelhante a camiseta do Vasco da Gama (sim/nao)");
                        System.out.print("R: ");
                        String bSegundaDecisaoCentroOeste = leitor.nextLine();

                        if (bSegundaDecisaoCentroOeste.equals("sim")) {
                            //codigo

                            System.out.println();
                            System.out.println("Seu time possui um estadio chamado Antônio Accioly (sim/nao) ?");
                            System.out.print("R: ");
                            String bTerceiraDecisaoCentroOeste = leitor.nextLine();

                            if (bTerceiraDecisaoCentroOeste.equals("sim")) {
                                //codigo

                                System.out.println();
                                System.out.println("Certo...");
                                System.out.println("Acredito que o time que esteja pensando seja o: ");
                                System.out.println();
                                System.out.println("Time: Atlético Goianiense");
                                System.out.println("Regiao: Cento-Oeste");
                                System.out.println("Fundacao: 1937");
                                System.out.println("Mascote: Dragao");
                                System.out.println("Estadio: Atlético Goianiense");
                                System.out.println("Cidade: Goiania");

                            } else if (bTerceiraDecisaoCentroOeste.equals("nao")) {
                                //codigo caso nao

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias...");
                                System.out.println("Atualmente nao existe um time que jogue na serie B, resida no Centro-Oeste, possui um dragao como mascote, possui uma camiseta similar a do Vasco da Gama e nao possua um estadio chamado 'Antônio Accioly'. ");

                            } else {
                                //codigo falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if (bSegundaDecisaoCentroOeste.equals("nao")) {
                            //codigo caso nao

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias...");
                            System.out.println("Atualmente nao existe um time que jogue na serie B, resida no Centro-Oeste, possui um dragao como mascote e nao tenha uma camiseta similar a do Vasco da Gama.");


                        } else {
                            //codigo falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }


                    } else if (bPrimeiraDescisaoCentroOeste.equals("nao")) { //Vila Nova-GO
                        //codigo caso nao

                        System.out.println();
                        System.out.println("Certo...");
                        System.out.println("Seu time possui um estadio chamado Onésio Brasileiro Alvarenga (sim/nao) ?");
                        System.out.print("R: ");
                        String bQuartaDecisaoCentroOeste = leitor.nextLine();

                        if (bQuartaDecisaoCentroOeste.equals("sim")) {
                            //codigo

                            System.out.println();
                            System.out.println("Seu time possui um tigre como mascote (sim/nao) ?");
                            System.out.print("R: ");
                            String bQuintaDecisaoCentroOeste = leitor.nextLine();

                            if (bQuintaDecisaoCentroOeste.equals("sim")) {
                                //codigo

                                System.out.println();
                                System.out.println("Certo...");
                                System.out.println("Acredito que seu time seja o: ");
                                System.out.println();
                                System.out.println("Time: Vila Nova-GO");
                                System.out.println("Regiao: Centro-Oeste");
                                System.out.println("Fundacao: 1943");
                                System.out.println("Mascote: Tigre");
                                System.out.println("Estadio: Onésio Brasileiro Alvarenga");
                                System.out.println("Cidade: Goiania");

                            } else if (bQuintaDecisaoCentroOeste.equals("nao")) {
                                //codigo caso nao

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe um time que jogue na serie B, resida no Centro-Oeste nao tenha um dragao como mascote, possua um estadio chamado 'Onésio Brasileiro Alvarenga' e nao tenha um tigre como mascote.");

                            } else {
                                //codigo falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if (bQuartaDecisaoCentroOeste.equals("nao")) {
                            //codigo caso nao

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                            System.out.println("Atualmente nao existe um time que jogue na serie B, resida no Centro-Oeste nao tenha um dragao como mascote e nem um estadio chamado 'Onésio Brasileiro Alvarenga'. ");

                        } else {
                            //codigo falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else {
                        //codigo falso

                        System.out.println();
                        System.out.println("Desculpe, ");
                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                        System.out.println("Obrigado e volte sempre !!");

                    }

                    break;

                case "sudeste": //times serie B do sudeste(7)
                    //Botafogo-SP
                    //Guarani
                    //Ituano
                    //Mirassol
                    //Novorizontino
                    //Tombense
                    //Ponte Petra
                    System.out.println();
                    System.out.println("Ja separei uma listinha de times do sudeste !!");
                    System.out.println();
                    System.out.println("O time que esteja pensando tem uma pantera como mascote (sim/nao) ?");
                    System.out.print("R: ");
                    String bPrimeiraDecisaoSudeste = leitor.nextLine();

                    if (bPrimeiraDecisaoSudeste.equals("sim")) {//botafogo-sp
                        //codigo

                        System.out.println();
                        System.out.println("Seu time possui Libertadores ou Mundial (sim/nao) ?");
                        System.out.print("R: ");
                        String bSegundaDecisaoSudeste = leitor.nextLine();

                        if (bSegundaDecisaoSudeste.equals("sim")) {
                            //codigo

                            System.out.println();
                            System.out.println("Desculpe, mas atualmente suas respostas possuem divergencias...");
                            System.out.println("Atualmente nao existe um time que joga na serie B, reside no sudeste, possui uma pantera como mascote e tenha libertadores ou mundial.");

                        } else if (bSegundaDecisaoSudeste.equals("nao")) {
                            //codigo caso nao

                            System.out.println();
                            System.out.println("Certo...");
                            System.out.println("O time possui as cores branca, vermelha e preta em seu escudo/brasao (sim/nao) ?");
                            System.out.print("R: ");
                            String bTerceiraDecisaoSudeste = leitor.nextLine();

                            if (bTerceiraDecisaoSudeste.equals("sim")) {
                                //codigo

                                System.out.println();
                                System.out.println("Entendi...");
                                System.out.println();
                                System.out.println("Acredito que seu time seja o: ");
                                System.out.println();
                                System.out.println("Time: Botafogo-SP");
                                System.out.println("Fundacao: 1918");
                                System.out.println("Mascote: Pantera");
                                System.out.println("Estadio: Santa Cruz");
                                System.out.println("Cidade: Ribeirao Preto");


                            } else if (bTerceiraDecisaoSudeste.equals("nao")) {
                                //codigo caso nao

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respotas possuem divergencias.");
                                System.out.println("Atualmente nao existe um time que joga na serie B, reside no sudeste, possui uma pantera como mascote, nao tenha libertadores e nem mundial e nao tenha as cores branca, vermelha e preta em seu escudo/brasao");

                            } else {
                                //codigo falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else {
                            //codigo falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else if (bPrimeiraDecisaoSudeste.equals("nao")) { // --------------------- outros timess
                        //codigo caso nao

                        System.out.println();
                        System.out.println("Seu time possui Libertadores ou Mundial (sim/nao) ?");
                        System.out.print("R: ");
                        String bQuartaDecisaoSudeste = leitor.nextLine();

                        if (bQuartaDecisaoSudeste.equals("sim")) {
                            //codigo

                            System.out.println();
                            System.out.println("Desculpe, mas atualmente nao existe nenhum time da serie B, que resida no sudeste e tenha uma Libertadores ou Mundial");

                        } else if (bQuartaDecisaoSudeste.equals("nao")) {
                            //codigo caso nao

                            System.out.println();
                            System.out.println("Entendi...");
                            System.out.println("Seu time possui as letras abreviadas 'GFC' em seu brasao/escudo (sim/nao) ?");
                            System.out.print("R: ");
                            String bQuintaDecisaoSudeste = leitor.nextLine();

                            if (bQuintaDecisaoSudeste.equals("sim")) { // Guarani
                                //codigo

                                System.out.println();
                                System.out.println("Certo...");
                                System.out.println("Seu time reside em Campinas (sim/nao) ?");
                                System.out.print("R: ");
                                String bSextaDecisaoSudeste = leitor.nextLine();

                                if (bSextaDecisaoSudeste.equals("sim")) {
                                    //codigo

                                    System.out.println();
                                    System.out.println("Acredito que o time que esteja pensando seja o: ");
                                    System.out.println();
                                    System.out.println("Time: Guarani");
                                    System.out.println("Regiao: Sudeste");
                                    System.out.println("Fundacao: 1911");
                                    System.out.println("Mascote: Bugre(Indio)");
                                    System.out.println("Estadio: Brinco de Ouro da Princesa");

                                } else if (bSextaDecisaoSudeste.equals("nao")) {
                                    //codigo caso nao

                                    System.out.println();
                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias");
                                    System.out.println("Atualmente nao existe um time que jogue na serie B, reside no sudeste, possui as letras abreviadas 'GFC', e nao resida em Campinas");

                                } else {
                                    //codigo falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }


                            } else if (bQuintaDecisaoSudeste.equals("nao")) { //---------outros times
                                //codigo caso nao

                                System.out.println();
                                System.out.println("Certo...");
                                System.out.println("Seu time possui o estadio 'Dr Novelli Junior' (sim/nao) ? ");
                                System.out.print("R: ");
                                String bSetimaDecisaoSudeste = leitor.nextLine();

                                if (bSetimaDecisaoSudeste.equals("sim")) { //----------- ituano
                                    //codigo

                                    System.out.println("Entendi...");
                                    System.out.println("Acredito que seu time seja o: ");
                                    System.out.println();
                                    System.out.println("Time: Ituano");
                                    System.out.println("Regiao: Sudeste");
                                    System.out.println("Fundacao: 1947");
                                    System.out.println("Mascote: Galo");
                                    System.out.println("Estadio: Dr. Novelli Junior");
                                    System.out.println("Cidade: Itu");

                                } else if (bSetimaDecisaoSudeste.equals("nao")) { //------------outros times
                                    //codigo caso nao

                                    System.out.println();
                                    System.out.println("Seu time possui um bixo preguica como mascote (sim/nao) ?");
                                    System.out.print("R: ");
                                    String bOitavaDecisaoSudeste = leitor.nextLine();

                                    if (bOitavaDecisaoSudeste.equals("sim")) {
                                        //codigo

                                        System.out.println();
                                        System.out.println("Desculpe mas nao existe um time na serie B que possua um bixo preguica, apenas perguntei para saber se o usuario sabe aonde quer chegar...");
                                        System.out.println();

                                    } else if (bOitavaDecisaoSudeste.equals("nao")) {
                                        //codigo caso nao

                                        System.out.println();
                                        System.out.println("Entendi...");
                                        System.out.println("O time que esta pensando foi fundado em 1925 (sim/nao) ?");
                                        System.out.print("R: ");
                                        String bNonaDecisaoSudeste = leitor.nextLine();

                                        if (bNonaDecisaoSudeste.equals("sim")) {
                                            //codigo

                                            System.out.println();
                                            System.out.println("Certo...");
                                            System.out.println("Acredito que o time seja o: ");
                                            System.out.println();
                                            System.out.println("Time: Mirassol");
                                            System.out.println("Regiao: Sudeste");
                                            System.out.println("Fundacao: 1925");
                                            System.out.println("Mascote: Leao");
                                            System.out.println("Estadio: Jose Maria de Campos Maia");
                                            System.out.println("Cidade: Mirassol");

                                        } else if (bNonaDecisaoSudeste.equals("nao")) {
                                            //codigo caso nao

                                            System.out.println();
                                            System.out.println("Certo...");
                                            System.out.println("Tenho alguns palpites em mente");
                                            System.out.println("O seu time possui um Tigre como mascote (sim/nao) ?");
                                            System.out.print("R: ");
                                            String bDecimaDecisaoSudeste = leitor.nextLine();

                                            if (bDecimaDecisaoSudeste.equals("sim")) {
                                                //codigo

                                                System.out.println();
                                                System.out.println("Entendi...");
                                                System.out.println("Acredito que seu time seja o: ");
                                                System.out.println();
                                                System.out.println("Time: Novorizontino");
                                                System.out.println("Regiao: Sudeste");
                                                System.out.println("Fundacao: 2010");
                                                System.out.println("Mascote: Tigre");
                                                System.out.println("Estadio: Doutor Jorge Ismael de Biassi");
                                                System.out.println("Cidade: Novo Horizonte");

                                            } else if (bDecimaDecisaoSudeste.equals("nao")) {
                                                //codigo caso nao

                                                System.out.println();
                                                System.out.println("Seu time se localiza na cidade de Tombos-MG (sim/nao) ?");
                                                System.out.print("R: ");
                                                String bDecimaPrimeiraDecisaoSudeste = leitor.nextLine();

                                                if (bDecimaPrimeiraDecisaoSudeste.equals("sim")) {
                                                    //codigo

                                                    System.out.println("Certo");
                                                    System.out.println("Acredito que seu time seja o: ");
                                                    System.out.println();
                                                    System.out.println("Time: Tombense");
                                                    System.out.println("Regiao: Sudeste");
                                                    System.out.println("Fundacao: 1914");
                                                    System.out.println("Mascote: Gaviao-Carcara");
                                                    System.out.println("Estadio");
                                                    System.out.println("Soares de Azevedo");
                                                    System.out.println("Cidade: Tombos-MG");

                                                } else if (bDecimaPrimeiraDecisaoSudeste.equals("nao")) {
                                                    //codigo caso nao

                                                    System.out.println();
                                                    System.out.println("O time possui as cores branca e preta em seu escudo/brasao juntamente com as abreviações A.A.P.P (sim/nao) ?");
                                                    System.out.print("R: ");
                                                    String bDecimaSegundaDecisaoSudeste = leitor.nextLine();

                                                    if (bDecimaSegundaDecisaoSudeste.equals("sim")) {
                                                        //codigo

                                                        System.out.println();
                                                        System.out.println("Acredito que seu time seja o: ");
                                                        System.out.println();
                                                        System.out.println("Time: Ponte Preta");
                                                        System.out.println("Regiao: Sudeste");
                                                        System.out.println("Fundacao: 1900");
                                                        System.out.println("Mascote: Macaco/Gorila");
                                                        System.out.println("Estadio: Moises Lucarelli");
                                                        System.out.println("Cidade: Campinas");

                                                    } else if (bDecimaSegundaDecisaoSudeste.equals("nao")) {
                                                        //codigo caso nao

                                                        System.out.println();
                                                        System.out.println("Parece que voce chegou ao fim.");
                                                        System.out.println("Muito provavelmente voce nao soube responder a pergunta relacionado ao seu time.");

                                                    } else {
                                                        //codigo falso

                                                        System.out.println();
                                                        System.out.println("Desculpe, ");
                                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                        System.out.println("Obrigado e volte sempre !!");

                                                    }

                                                } else {
                                                    //codigo falso

                                                    System.out.println();
                                                    System.out.println("Desculpe, ");
                                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                    System.out.println("Obrigado e volte sempre !!");

                                                }

                                            } else {
                                                //codigo falso

                                                System.out.println();
                                                System.out.println("Desculpe, ");
                                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                                System.out.println("Obrigado e volte sempre !!");

                                            }

                                        } else {
                                            //codigo falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");
                                        }

                                    } else {
                                        //codigo falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else {
                                    //codigo falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else {
                                //codigo falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else {
                            //codigo falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else {
                        //codigo falso

                        System.out.println();
                        System.out.println("Desculpe, ");
                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                        System.out.println("Obrigado e volte sempre !!");

                    }

                    break;

                case "sul": //times serie B do sul(5)
                    //Avaí ------------------ FEITO
                    //Chapecoense ----------- FEITO
                    //Criciúma -------------- FEITO
                    //Juventude ------------- FEITO
                    //Londrina -------------- FEITO

                    System.out.println();
                    System.out.println("Certo...");
                    System.out.println("Seu time possui apenas as cores azul e branco no seu brasao/escudo (sim/nao) ?");
                    System.out.print("R: ");
                    String bPrimeiraDecisaoSul = leitor.nextLine();

                    if (bPrimeiraDecisaoSul.equals("sim")) { //Avai
                        //código

                        System.out.println();
                        System.out.println("Entendi...");
                        System.out.println("Seu time possui e de Florianopolis (sim/nao) ?");
                        System.out.print("R: ");
                        String bSegundaDecisaoSul = leitor.nextLine();

                        if (bSegundaDecisaoSul.equals("sim")) {
                            //código

                            System.out.println();
                            System.out.println("Tenho um palpite em mente.");
                            System.out.println("Seu time possui um mascote que no reino animal e conhecido como o 'rei da selva' (sim/nao) ?");
                            System.out.print("R: ");
                            String bTerceiraDecisaoSul = leitor.nextLine();

                            if (bTerceiraDecisaoSul.equals("sim")) {
                                //código

                                System.out.println();
                                System.out.println("Acredito que seu time seja o: ");
                                System.out.println();
                                System.out.println("Time: Avai");
                                System.out.println("Regiao: Sul");
                                System.out.println("Fundacao: 1923");
                                System.out.println("Mascote: Leao");
                                System.out.println("Estadio: Aderbal Ramos da Silva");
                                System.out.println("Cidade: Florianopolis");

                            } else if (bTerceiraDecisaoSul.equals("nao")) {
                                //codigo valido caso oposto do primeiro

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe um time que joga na serie B, possua o brasao/escudo com as cores azul e branco, resida em Florianopolis e nao tenha um Leao como mascote.");

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if (bSegundaDecisaoSul.equals("nao")) {
                            //codigo valido caso oposto do primeiro

                            System.out.println();
                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                            System.out.println("Atualmente nao existe um time que joga na serie B, possua o brasao/escudo com as cores azul e branco e nao resida em florianopolis.");

                        } else {
                            //código falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else if (bPrimeiraDecisaoSul.equals("nao")) {// CHAPECOENSE
                        //codigo valido caso oposto do primeiro

                        System.out.println();
                        System.out.println("Certo...");
                        System.out.println("O time na qual esta pensando e lembrado na historia do futebol pelo acidente envolvendo a tragica queda de um aviao que transportava o time incluido atletas e comissao tecnica no ano de 2016 (sim/nao) ?");
                        System.out.print("R: ");
                        String bTerceiraDecisaoSul = leitor.nextLine();

                        if (bTerceiraDecisaoSul.equals("sim")) {
                            //código

                            System.out.println();
                            System.out.println("Certo...");
                            System.out.println("O time na qual esteja pensando possui um Indio como mascote (sim/nao) ?");
                            System.out.print("R: ");
                            String bQuartaDecisaoSul = leitor.nextLine();

                            if (bQuartaDecisaoSul.equals("sim")) {
                                //código

                                System.out.println();
                                System.out.println("Certo...");
                                System.out.println("Acredito que esteja pensando no: ");
                                System.out.println();
                                System.out.println("Time: Chapecoense");
                                System.out.println("Regiao: Sul");
                                System.out.println("Fundacao: 1973");
                                System.out.println("Mascote: Indio");
                                System.out.println("Estadio: Arena Conda");
                                System.out.println("Cidade: Chapeco");
                                System.out.println();
                                System.out.println("Em tempos de dor e tristeza, e importante lembrar que a uniao e o amor sao as forcas que nos ajudam a superar as dificuldades. Embora as perdas sejam irreparaveis, o legado e a memoria dos que se foram sempre permanecerao. Que a solidariedade e o apoio mutuo possam trazer conforto e forca para todos os familiares, amigos e fas da Chapecoense, e que possamos encontrar alguma paz e esperanca em meio a tanta dor.");
                                System.out.println();
                                System.out.println("#forcachape");

                            } else if (bQuartaDecisaoSul.equals("nao")) {
                                //codigo valido caso oposto do primeiro

                                System.out.println();
                                System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                System.out.println("Atualmente nao existe um time que jogue na serie B, reside na regiao Sul, nao possui as cores azul e branca em sua camiseta, seja lembrado na historia do futebol pela tragedia no ano de 2016 e nao possua um indio como mascote.");


                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else if (bTerceiraDecisaoSul.equals("nao")) { //Criciuma
                            //codigo valido caso oposto do primeiro

                            System.out.println();
                            System.out.println("Seu time possui o 'tigrao' como mascote (sim/nao) ? ");
                            System.out.print("R: ");
                            String bQuartaDecisaoSul = leitor.nextLine();

                            if (bQuartaDecisaoSul.equals("sim")) { //sim
                                //código

                                System.out.println();
                                System.out.println("Seu time que se localiza na regiao Sul do Brasil, tambem se localiza na regiao Sul de Santa Catarina (sim/nao) ? ");
                                System.out.print("R: ");
                                String bQuintaDecisaoSul = leitor.nextLine();

                                if (bQuintaDecisaoSul.equals("sim")) {
                                    //código

                                    System.out.println();
                                    System.out.println("Seu time possui um estadio chamado 'Heribelto Hulse' (sim/nao) ?");
                                    System.out.print("R: ");
                                    String bSextaDecisaoSul = leitor.nextLine();

                                    if (bSextaDecisaoSul.equals("sim")) {
                                        //código

                                        System.out.println();
                                        System.out.println("Acredito que seu time seja o: ");
                                        System.out.println();
                                        System.out.println("Time: Criciuma");
                                        System.out.println("Fundacao: 1947");
                                        System.out.println("Mascote: Tigrao");
                                        System.out.println("Estadio: Heribelto Hulse");
                                        System.out.println("Cidade: Criciuma");

                                    } else if (bSextaDecisaoSul.equals("nao")) {
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                        System.out.println("Atualmente nao existe um time que joga na serie B, reside na regiao Sul, possui um mascote chamado 'tigrao', se localiza na regiao Sul de Santa Catarina e nao possui um estadio chamado 'Heribelto Hulse'.");

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else if (bQuintaDecisaoSul.equals("nao")) {
                                    //codigo valido caso oposto do primeiro

                                    System.out.println();
                                    System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                    System.out.println("Atualmente nao existe um time que joga na serie B, reside na regiao Sul, possui um mascote chamado 'tigrao' e nao se localiza na regiao Sul de Santa Catarina.");

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else if (bQuartaDecisaoSul.equals("nao")) {// Outros times
                                //codigo valido caso oposto do primeiro

                                System.out.println();
                                System.out.println("Certo...");
                                System.out.println("O time na qual esteja pensando possui uma fase da vida humana que se refere a idade compreendida entre a adolescencia e a idade adulta como nome (sim/nao) ? ");
                                System.out.print("R: ");
                                String bQuintaDecisaoSul = leitor.nextLine();

                                if (bQuintaDecisaoSul.equals("sim")) { //Juventude
                                    //código

                                    System.out.println();
                                    System.out.println("Certo...");
                                    System.out.println("O time que esta pensando possui um periquito como mascote (sim/nao) ?");
                                    System.out.print("R: ");
                                    String bSextaDecisaoSul = leitor.nextLine();

                                    if (bSextaDecisaoSul.equals("sim")) {
                                        //código

                                        System.out.println();
                                        System.out.println("O time possui as cores verde e branca em seu brasao/escudo (sim/nao) ?");
                                        System.out.print("R: ");
                                        String bSetimaDecisaoSul = leitor.nextLine();

                                        if (bSetimaDecisaoSul.equals("sim")) {
                                            //código

                                            System.out.println();
                                            System.out.println("Acredito que seu time seja o: ");
                                            System.out.println();
                                            System.out.println("Time: Juventude");
                                            System.out.println("Regiao: Sul");
                                            System.out.println("Fundacao: 1913");
                                            System.out.println("Mascote: Periquito");
                                            System.out.println("Estadio: Alfredo Jaconi");
                                            System.out.println("Cidade: Caxias do Sul");

                                        } else if (bSetimaDecisaoSul.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Desculpe, mas atualmente suas respostas possuem divergencias.");
                                            System.out.println("Atualmente nao existe um time que joga na serie B, reside na regiao Sul, possui o nome do time uma fase da vida, possui um periquito como mascote e nao possui as cores do time verde e branca em seu brasao/escudo.");

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else if (bSextaDecisaoSul.equals("nao")) {
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                        System.out.println("Atualmente nao existe um time que joga na serie B, reside na regiao Sul, possui o nome do time uma fase da vida e nao possua um periquito como mascote");

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else if (bQuintaDecisaoSul.equals("nao")) {//OUTRO TIME(LONDRINA)
                                    //codigo valido caso oposto do primeiro

                                    System.out.println();
                                    System.out.println("Entendi...");
                                    System.out.println("Seu time possui uma rama de cafe em seu escudo/brasao (sim/nao) ?");
                                    System.out.print("R: ");
                                    String bSextaDecisaoSul = leitor.nextLine();

                                    if (bSextaDecisaoSul.equals("sim")) {
                                        //código

                                        System.out.println();
                                        System.out.println("Certo...");
                                        System.out.println("Seu time possui um tubarao como mascote (sim/nao) ?");
                                        System.out.print("R: ");
                                        String bSetimaDecisao = leitor.nextLine();

                                        if (bSetimaDecisao.equals("sim")) {
                                            //código

                                            System.out.println();
                                            System.out.println("Acredito que seu time seja o: ");
                                            System.out.println();
                                            System.out.println("Time: Londrina");
                                            System.out.println("Regiao: Sul");
                                            System.out.println("Fundacao: 1956");
                                            System.out.println("Mascote: Tubarao");
                                            System.out.println("Estadio: Estadio do cafe");
                                            System.out.println("Cidade: Londrina");

                                        } else if (bSetimaDecisao.equals("nao")) {
                                            //codigo valido caso oposto do primeiro

                                            System.out.println();
                                            System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                            System.out.println("Atualmente nao existe um time que jogue na serie B, reside na regiao Sul, possui um escudo/brasao uma rama de cafe e nao possua um tubarao como mascote.");

                                        } else {
                                            //código falso

                                            System.out.println();
                                            System.out.println("Desculpe, ");
                                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                            System.out.println("Obrigado e volte sempre !!");

                                        }

                                    } else if (bSextaDecisaoSul.equals("nao")) {
                                        //codigo valido caso oposto do primeiro

                                        System.out.println();
                                        System.out.println("Desculpe, mas as suas respostas possuem divergencias.");
                                        System.out.println("Atualmente todas as logicas foram atingidas para a serie B da regiao Sul do Brasil ");

                                    } else {
                                        //código falso

                                        System.out.println();
                                        System.out.println("Desculpe, ");
                                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                        System.out.println("Obrigado e volte sempre !!");

                                    }

                                } else {
                                    //código falso

                                    System.out.println();
                                    System.out.println("Desculpe, ");
                                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                    System.out.println("Obrigado e volte sempre !!");

                                }

                            } else {
                                //código falso

                                System.out.println();
                                System.out.println("Desculpe, ");
                                System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                                System.out.println("Obrigado e volte sempre !!");

                            }

                        } else {
                            //código falso

                            System.out.println();
                            System.out.println("Desculpe, ");
                            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                            System.out.println("Obrigado e volte sempre !!");

                        }

                    } else {
                        //código falso

                        System.out.println();
                        System.out.println("Desculpe");
                        System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                        System.out.println("Obrigado e volte sempre !!");

                    }

                    break;

                default:

                    System.out.println();
                    System.out.println("Desculpe");
                    System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
                    System.out.println("Obrigado e volte sempre !!");

            }

        }  else {

            System.out.println();
            System.out.println("Desculpe, ");
            System.out.println("Mas nao entendi sua resposta, por favor digite conforme as sugestoes.");
            System.out.println("Obrigado e volte sempre !!");

        }

        leitor.close();

    }
}